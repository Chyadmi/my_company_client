/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycompany_v1.pkg1;

import bean.Salarie;
import helper.DemandeAugmentationFxHelper;
import helper.DemandeAvanceFxHelper;
import helper.DemandeCongeFxHelper;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import service.DemandeFacade;
import sun.security.util.Password;
import util.Session;

/**
 * FXML Controller class
 *
 * @author hamza
 */
public class DirecteurAccueilFXMLController implements Initializable {

    DemandeFacade demandeFacade = new DemandeFacade();

    private DemandeCongeFxHelper demandeCongeFxHelper;
    private DemandeAvanceFxHelper demandeAvanceFxHelper;
    private DemandeAugmentationFxHelper demandeAugmentationFxHelper;

    @FXML
    private Label close;

    @FXML
    private Label fullname;

    @FXML
    private TextField nom;
    @FXML
    private TextField prenom;
    @FXML
    private TextField telephone;
    @FXML
    private TextField login;
    @FXML
    private PasswordField motdepasse;
    @FXML
    private TextField departement;
    @FXML
    private TextField fonction;
    @FXML
    private TextField salaire;

    private void initForm() {
        Salarie sal = ((Salarie) Session.getAttribut("connectedUser"));
        nom.setText(sal.getNom());
        prenom.setText(sal.getPrenom());
        telephone.setText(sal.getTelephone());
        login.setText(sal.getLogin());
        departement.setText(sal.getDepartement().getNom());
        fonction.setText(sal.getRole().getLibelle());
        salaire.setText(sal.getSalaire() + "");
    }

    @FXML
    private void toMesDemandes(ActionEvent actionEvent) throws IOException {
        ViewLauncher.forward(actionEvent, "EmployeDemandeFXML.fxml", this.getClass());
    }

    @FXML
    private void toBoiteReception(ActionEvent actionEvent) throws IOException {
        ViewLauncher.forward(actionEvent, "BoiteFXML.fxml", this.getClass());
    }

    @FXML
    private void toProfile(ActionEvent actionEvent) throws IOException {
        ViewLauncher.forward(actionEvent, "EmployeAccueilFXML.fxml", this.getClass());
    }

    @FXML
    private void seDeconnecter(ActionEvent actionEvent) throws IOException {
        Session.clear();
        ViewLauncher.forward(actionEvent, "LoginFXML.fxml", this.getClass());
    }

    @FXML
    public void closeApp() {
        Stage stage = (Stage) close.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void minimizeApp(ActionEvent event) {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.setIconified(true);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        Salarie sal = ((Salarie) Session.getAttribut("connectedUser"));
        String name = sal.getNom() + " " + sal.getPrenom();
        fullname.setText(name);
        initForm();
    }

}
